from .ChessProject import *

__doc__ = ChessProject.__doc__
if hasattr(ChessProject, "__all__"):
    __all__ = ChessProject.__all__